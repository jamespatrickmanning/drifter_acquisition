"""
spreadsheet.py
Created on June 19, 2019
Author: Dylan Montagu

Accesses drift_header.DRIFT_HEADER (google sheet) on the noaa.drifters@gmail.com account
getfix_gs_data grabs data necessary for getfix.py, and returns that data
as a dictionary
getfix_ap3_gs_data grabs data necessary for getfix_ap3.py, and returns that data
as a dictionary.
If program run directly, runs get_gs_data and getfix_ap3_gs_data, and prints
formatted for display version of the dictinoaries

noaa_drifter_crednetials.json needs to be in same directory as spreadsheet.py
"""

import gspread
from oauth2client.service_account import ServiceAccountCredentials
from dateutil.parser import parse
import numpy as np


def getfix_gs_data(project_name):
    """
    Accesses data on drift_header.gs
    Gets raw data from the first 6 columns (id, esn, case_id, start_date, end_date, and drogue_depth),
    selects rows of the project name being worked on, and returns a dictionary with meta data of all
    entries in the project

    Returns a dictionary with
        keys =     id,      esn,   case_id,      start_date,              end_date,    drogue_depth
        values = <[int]>, <[int]>, <[int]>, [<datetime.datetime>], [<datetime.datetime>], <[int]>

    in: project_name <string>
    out: output_data <dict>
    """

    # set up google sheet access
    scope = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']
    creds = ServiceAccountCredentials.from_json_keyfile_name("noaa_drifter_credentials.json", scope)
    client = gspread.authorize(creds)
    sheet = client.open('drift_header').get_worksheet(0) # specify which "tab" accessed

    # access individual column data
    # col indexes start at 1, elts are returned as strings
    id = sheet.col_values(1)[1:6]
    esn = sheet.col_values(2)[1:6]
    case_id = sheet.col_values(3)[1:6]
    start_date = sheet.col_values(4)[1:6]
    end_date = sheet.col_values(5)[1:6]
    drogue_depth = sheet.col_values(6)[1:6]
    project_names = sheet.col_values(14)[1:6]

    # clean data types
    for i in range(len(id)):
        #id[i] = int(id[i])
        #esn[i] = int(esn[i])
        case_id[i] = int(case_id[i])
        #drogue_depth[i] = int(drogue_depth[i])
        start_date[i] = parse(start_date[i])
        end_date[i] = parse(end_date[i])

    # find indexes of rows of project that we want to get metadata for
    project_indexes = []
    for index, name in enumerate(project_names):
        if name == project_name:
            project_indexes.append(index)

    # set up data and info for reformatting, and output as dicitonary
    all_data_raw = [id, esn, case_id, start_date, end_date, drogue_depth]
    data_titles = ["id", "esn", "case_id", "start_date", "end_date", "drogue_depth"]
    output_data = {}
    for index, col in enumerate(all_data_raw):
        col_data = []
        for row in (project_indexes): # only get data from rows of the project we're getting info from
            col_data.append(col[row])
        output_data[data_titles[index]] = col_data

    return output_data


def getfix_ap3_gs_data():
    """
    ap3 version, same as getfix_gs_data but different subsect (columns)
    of data accesed and returned

    Accesses all rows that don't utilized GLOBALSTAR satellite communication links
    which should signel out miniboats (hopefully)

    in: <>
    out: output_data <dict>
    """

    # set up google sheet access
    scope = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']
    creds = ServiceAccountCredentials.from_json_keyfile_name("noaa_drifter_credentials.json", scope)
    client = gspread.authorize(creds)
    sheet = client.open('drift_header').get_worksheet(0) # specify which gs accessed

    # access individual column data
    id = sheet.col_values(1)[1:]
    esn = sheet.col_values(2)[1:]
    case_id = sheet.col_values(3)[1:]
    start_date = sheet.col_values(4)[1:]
    end_date = sheet.col_values(5)[1:]
    drogue_depth = sheet.col_values(6)[1:]
    project_names = sheet.col_values(14)[1:]
    boat_pi = sheet.col_values(16)[1:]
    school = sheet.col_values(15)[1:]
    consecutive_batch = sheet.col_values(22)[1:]
    communication = sheet.col_values(20)[1:]

    # clean data types
    for i in range(len(id)):
        # id[i] = int(id[i])
        # esn[i] = int(esn[i])
        case_id[i] = int(case_id[i])
        # drogue_depth[i] = int(drogue_depth[i])
        start_date[i] = parse(start_date[i])
        end_date[i] = parse(end_date[i])
        # consecutive_batch[i] = int(consecutive_batch[i])

    # find indexes of rows of project that we want to get metadata for
    project_indexes = []
    for index, name in enumerate(communication):
        if name != "GLOBALSTAR":
            project_indexes.append(index)

    # set up data and info for reformatting, and output as dicitonary
    all_data_raw = [id, esn, case_id, start_date, end_date, drogue_depth, boat_pi, school, consecutive_batch, project_names]
    data_titles = ["id", "esn", "case_id", "start_date", "end_date", "drogue_depth", "boat_pi", "school", "consecutive_batch", "project_names"]
    output_data = {}
    for index, col in enumerate(all_data_raw):
        col_data = []
        for row in (project_indexes): # only get data from entries that are not GLOBALSTAR
            col_data.append(col[row])
        output_data[data_titles[index]] = col_data

    return output_data


if __name__ == "__main__":
    """ prints data returned from get_gs_data in clean format """

    output_data = getfix_gs_data("TEST")
    for field, data in output_data.items():
        print(field, ":", data)

    output_data = getfix_ap3_gs_data()
    for field, data in output_data.items():
        print(field, ":", data)
